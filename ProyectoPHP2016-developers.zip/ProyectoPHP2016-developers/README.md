# ProyectoPHP2016
En este proyecto vamos a crear una aplicación web que asesore a los clientes de una clínica llamada Maphre EUSA.

La estructura básica de este proyecto se desarrollará en el siguiente directorio:

/web/php

Colgando de la carpeta php estarán todos los ficheros y carpetas donde se desarrollará la aplicación.

Todos los commits de los desarrolladores se realizarán en la rama "Developer" mientras que en Test se integrán estos desarrollo con lo que haya en la rama MASTER hasta la fecha.

Si todas las pruebas son correctas, se subirán a la rama MASTER en caso contrario se retirará el comit por incompatibilidad.

Muchas gracias por tu participación.
